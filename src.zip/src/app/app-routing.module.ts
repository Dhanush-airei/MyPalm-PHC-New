import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './shared/guards/auth/auth-guard';
import { LoginGuard } from './shared/guards/login/login-guard';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full',
  },
  {
    path: 'tabs',
    loadChildren: () =>
      import('./tabs/tabs.module').then((m) => m.TabsPageModule),
    canActivate: [AuthGuard],
  },
  {
    path: 'login',
    loadChildren: () =>
      import('./pages/auth/login/login.module').then((m) => m.LoginPageModule),
    canActivate: [LoginGuard],
  },
  {
    path: 'profile',
    loadChildren: () =>
      import('./pages/auth/profile/profile.module').then(
        (m) => m.ProfilePageModule,
      ),
  },
  {
    path: 'grader-dashboard',
    loadChildren: () =>
      import('./pages/production/grader/grader-dashboard/grader-dashboard.module').then(
        (m) => m.GraderDashboardPageModule,
      ),
  },
  {
    path: 'grader-report',
    loadChildren: () =>
      import('./pages/production/grader/grader-report/grader-report.module').then(
        (m) => m.GraderReportPageModule,
      ),
  },
  {
    path: 'change-password',
    loadChildren: () =>
      import('./pages/auth/change-password/change-password.module').then(
        (m) => m.ChangePasswordPageModule,
      ),
  },
  {
    path: 'logout',
    loadChildren: () =>
      import('./pages/auth/logout/logout.module').then(
        (m) => m.LogoutPageModule,
      ),
  },
  {
    path: 'delete-account',
    loadChildren: () =>
      import('./pages/auth/delete-account/delete-account.module').then(
        (m) => m.DeleteAccountPageModule,
      ),
  },
  {
    path: 'grader-vehicle-search',
    loadChildren: () =>
      import('./pages/production/grader/grader-vehicle-search/grader-vehicle-search.module').then(
        (m) => m.GraderVehicleSearchPageModule,
      ),
  },
  {
    path: 'grader-supplier-search',
    loadChildren: () =>
      import('./pages/production/grader/grader-supplier-search/grader-supplier-search.module').then(
        (m) => m.GraderSupplierSearchPageModule,
      ),
  },
  {
    path: 'maintenance-dashboard',
    loadChildren: () =>
      import('./pages/maintenance/maintenance-dashboard/maintenance-dashboard.module').then(
        (m) => m.MaintenanceDashboardPageModule,
      ),
  },
  {
    path: 'weighbridge-home',
    loadChildren: () =>
      import('./pages/production/weighbridge/weighbridge-home/weighbridge-home.module').then(
        (m) => m.WeighbridgeHomePageModule,
      ),
  },
  {
    path: 'weighbridge-report',
    loadChildren: () =>
      import('./pages/production/weighbridge/weighbridge-report/weighbridge-report.module').then(
        (m) => m.WeighbridgeReportPageModule,
      ),
  },
  {
    path: 'weighbridge-update',
    loadChildren: () =>
      import('./pages/production/weighbridge/weighbridge-update/weighbridge-update.module').then(
        (m) => m.WeighbridgeUpdatePageModule,
      ),
  },
  {
    path: 'weighbridge-update-report',
    loadChildren: () =>
      import('./pages/production/weighbridge/weighbridge-update-report/weighbridge-update-report.module').then(
        (m) => m.WeighbridgeUpdateReportPageModule,
      ),
  },
  {
    path: 'sterilizer-dashboard',
    loadChildren: () =>
      import('./pages/production/sterilizer/sterilizer-dashboard/sterilizer-dashboard.module').then(
        (m) => m.SterilizerDashboardPageModule,
      ),
  },
  {
    path: 'sterilizer-report',
    loadChildren: () =>
      import('./pages/production/sterilizer/sterilizer-report/sterilizer-report.module').then(
        (m) => m.SterilizerReportPageModule,
      ),
  },
  {
    path: 'sterilizer-alert',
    loadChildren: () =>
      import('./pages/production/sterilizer/sterilizer-alert/sterilizer-alert.module').then(
        (m) => m.SterilizerAlertPageModule,
      ),
  },
  {
    path: 'dooropenlater-update-modal',
    loadChildren: () =>
      import('./pages/production/sterilizer/dooropenlater-update-modal/dooropenlater-update-modal.module').then(
        (m) => m.DooropenlaterUpdateModalPageModule,
      ),
  },
  {
    path: 'production-hourly-sterilizer-station',
    loadChildren: () =>
      import('./pages/production/sterilizer/production-hourly-sterilizer-station/production-hourly-sterilizer-station.module').then(
        (m) => m.ProductionHourlySterilizerStationPageModule,
      ),
  },
  {
    path: 'alert-acknowledge',
    loadChildren: () =>
      import('./pages/production/sterilizer/alert-acknowledge/alert-acknowledge.module').then(
        (m) => m.AlertAcknowledgePageModule,
      ),
  },
  {
    path: 'press-dashboard',
    loadChildren: () =>
      import('./pages/production/press/press-dashboard/press-dashboard.module').then(
        (m) => m.PressDashboardPageModule,
      ),
  },
  {
    path: 'press-alert',
    loadChildren: () =>
      import('./pages/production/press/press-alert/press-alert.module').then(
        (m) => m.PressAlertPageModule,
      ),
  },
  {
    path: 'press-report',
    loadChildren: () =>
      import('./pages/production/press/press-report/press-report.module').then(
        (m) => m.PressReportPageModule,
      ),
  },
  {
    path: 'production-hourly-press-station',
    loadChildren: () =>
      import('./pages/production/press/production-hourly-press-station/production-hourly-press-station.module').then(
        (m) => m.ProductionHourlyPressStationPageModule,
      ),
  },
  {
    path: 'notification-view',
    loadChildren: () =>
      import('./pages/notification/notification-view/notification-view.module').then(
        (m) => m.NotificationViewPageModule,
      ),
  },
  {
    path: 'notification-alert',
    loadChildren: () =>
      import('./pages/notification/notification-alert/notification-alert.module').then(
        (m) => m.NotificationAlertPageModule,
      ),
  },
  {
    path: 'notification-reminder',
    loadChildren: () =>
      import('./pages/notification/notification-reminder/notification-reminder.module').then(
        (m) => m.NotificationReminderPageModule,
      ),
  },
  //FMANAGER
  {
    path: 'management-oil-losses',
    loadChildren: () =>
      import('./pages/management/fmanager/management-oil-losses/management-oil-losses.module').then(
        (m) => m.ManagementOilLossesPageModule,
      ),
  },
  {
    path: 'management-production',
    loadChildren: () =>
      import('./pages/management/fmanager/management-production/management-production.module').then(
        (m) => m.ManagementProductionPageModule,
      ),
  },
  {
    path: 'management-maintenance',
    loadChildren: () =>
      import('./pages/management/fmanager/management-maintenance/management-maintenance.module').then(
        (m) => m.ManagementMaintenancePageModule,
      ),
  },
  {
    path: 'management-report',
    loadChildren: () =>
      import('./pages/management/fmanager/management-report/management-report.module').then(
        (m) => m.ManagementReportPageModule,
      ),
  },
  {
    path: 'oil-loss-recommendation-modal',
    loadChildren: () =>
      import('./pages/management/fmanager/oil-loss-recommendation-modal/oil-loss-recommendation-modal.module').then(
        (m) => m.OilLossRecommendationModalPageModule,
      ),
  },
  {
    path: 'oil-losses-new',
    loadChildren: () =>
      import('./pages/management/fmanager/oil-losses-new/oil-losses-new.module').then(
        (m) => m.OilLossesNewPageModule,
      ),
  },
  {
    path: 'management-production-summary',
    loadChildren: () =>
      import('./pages/management/fmanager/management-production-summary/management-production-summary.module').then(
        (m) => m.ManagementProductionSummaryPageModule,
      ),
  },
  {
    path: 'reports',
    loadChildren: () =>
      import('./pages/reports/reports.module').then((m) => m.ReportsPageModule),
  },
  {
    path: 'oil-losses-summary',
    loadChildren: () =>
      import('./pages/production/reports/oil-losses-summary/oil-losses-summary.module').then(
        (m) => m.OilLossesSummaryPageModule,
      ),
  },
  {
    path: 'performance-analysis',
    loadChildren: () =>
      import('./pages/production/reports/performance-analysis/performance-analysis.module').then(
        (m) => m.PerformanceAnalysisPageModule,
      ),
  },
  {
    path: 'corrective-maintenance',
    loadChildren: () =>
      import('./pages/maintenance/reports/corrective-maintenance/corrective-maintenance.module').then(
        (m) => m.CorrectiveMaintenancePageModule,
      ),
  },
  {
    path: 'popup-notification-view',
    loadChildren: () =>
      import('./pages/maintenance/reports/popup-notification-view/popup-notification-view.module').then(
        (m) => m.PopupNotificationViewPageModule,
      ),
  },
  {
    path: 'preventive-maintenance',
    loadChildren: () =>
      import('./pages/maintenance/reports/preventive-maintenance/preventive-maintenance.module').then(
        (m) => m.PreventiveMaintenancePageModule,
      ),
  },
  {
    path: 'predictive-maintenance',
    loadChildren: () =>
      import('./pages/maintenance/reports/predictive-maintenance/predictive-maintenance.module').then(
        (m) => m.PredictiveMaintenancePageModule,
      ),
  },
  {
    path: 'predictive-maintenance-rejected-records',
    loadChildren: () =>
      import('./pages/maintenance/reports/predictive-maintenance-rejected-records/predictive-maintenance-rejected-records.module').then(
        (m) => m.PredictiveMaintenanceRejectedRecordsPageModule,
      ),
  },
  {
    path: 'machineries-running-hours',
    loadChildren: () =>
      import('./pages/maintenance/reports/machineries-running-hours/machineries-running-hours.module').then(
        (m) => m.MachineriesRunningHoursPageModule,
      ),
  },
  {
    path: 'part-running-hours',
    loadChildren: () =>
      import('./pages/maintenance/reports/part-running-hours/part-running-hours.module').then(
        (m) => m.PartRunningHoursPageModule,
      ),
  },
  {
    path: 'laboratory',
    loadChildren: () =>
      import('./pages/production/reports/laboratory/laboratory.module').then(
        (m) => m.LaboratoryPageModule,
      ),
  },
  {
    path: 'daily-ffa-quality',
    loadChildren: () =>
      import('./pages/production/reports/daily-ffa-quality/daily-ffa-quality.module').then(
        (m) => m.DailyFfaQualityPageModule,
      ),
  },
  {
    path: 'cpo-pk-stock',
    loadChildren: () =>
      import('./pages/production/reports/cpo-pk-stock/cpo-pk-stock.module').then(
        (m) => m.CpoPkStockPageModule,
      ),
  },
  /**
   * Redirects unmatched URLs based on authentication state.
   * Keep this wildcard route as the last route.
   */
  {
    path: '**',
    redirectTo: () => {
      const user = localStorage.getItem('userlist');

      return user ? '/tabs' : '/login';
    },
  },
];
@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules }),
  ],
  exports: [RouterModule],
})
export class AppRoutingModule {}
