import { Component, OnInit } from '@angular/core';
import { ViewChild } from '@angular/core';
import { IonContent } from '@ionic/angular';
import { UserContext } from 'src/app/shared/services/user-context-service/user-context';
import { UserProfileComponent } from 'src/app/shared/components/user-profile/user-profile.component';

@Component({
  selector: 'app-maintenance-dashboard',
  templateUrl: './maintenance-dashboard.page.html',
  styleUrls: ['./maintenance-dashboard.page.scss'],
  standalone: false,
})
export class MaintenanceDashboardPage implements OnInit {
  @ViewChild(UserProfileComponent)
  UserProfileComponent!: UserProfileComponent;

  appTitle = this.nl2br(this.UserContext.millName);
  headerActions = '';
  showLogo = 1;
  showBackButton = 0;

  constructor(private UserContext: UserContext) {}

  ngOnInit() {}

  ionViewWillEnter() {
    this.UserProfileComponent.loadUser();
  }

  nl2br(text: string) {
    return text.replace(new RegExp('\r?\n', 'g'), '<br />');
  }
}
