/* management-maintenance.page.ts */
import { Component, OnInit, DestroyRef, inject } from '@angular/core';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { finalize } from 'rxjs';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { TranslateService } from '@ngx-translate/core';

import { UserContext } from 'src/app/shared/services/user-context-service/user-context';
import { LanguageService } from 'src/app/shared/services/language-service/language-service';
import { SterilizerService } from 'src/app/shared/services/production-services/sterilizer-service/sterilizer-service';
import { ManagementService } from 'src/app/shared/services/management-service/management-service';

@Component({
  selector: 'app-management-maintenance',
  templateUrl: './management-maintenance.page.html',
  styleUrls: ['./management-maintenance.page.scss'],
  standalone: false,
})
export class ManagementMaintenancePage implements OnInit {
  private destroyRef = inject(DestroyRef);

  // Header Configuration
  appTitle: string = '';
  headerActions: string = '0';
  showLogo: number = 1;
  showBackButton: number = 0;

  // User Data
  userDesignation: number = 0;
  userId: number = 0;
  millCode: string = '';
  departmentId: number = 0;
  designationId: number = 0;

  // Form
  maintenanceForm: FormGroup;

  // Data Arrays
  correctivemaintenanceArr: any[] = [];
  routinepreventivemaintenanceArr: any[] = [];
  replacementpreventivemaintenanceArr: any[] = [];
  predictivemaintenanceArr: any[] = [];

  // Date
  reportDateDisplay: string = '';
  reportDateExternal: string = '';
  private reportDateForAPI: string = '';

  // Counts
  maintenanceCount: number = 0;
  maintenanceCountLength: number = 0;
  totalCount: number = 0;

  // Flags
  pleaseWaitFlag: boolean = false;

  constructor(
    private fb: FormBuilder,
    private translate: TranslateService,
    private userContext: UserContext,
    private languageService: LanguageService,
    private managementService: ManagementService,
    private sterilizerService: SterilizerService,
  ) {
    // Initialize user data from UserContext
    this.userDesignation = this.userContext.designId || 0;
    this.userId = this.userContext.userId || 0;
    this.millCode = this.userContext.millCode || '';
    this.departmentId = this.userContext.departmentId || 0;
    this.designationId = this.userContext.designId || 0;

    // Set app title
    this.appTitle = this.nl2br(this.userContext.millName || '');

    // Initialize form
    this.maintenanceForm = this.fb.group({
      pickdate: new FormControl(''),
    });
  }

  ngOnInit(): void {}

  ionViewDidEnter(): void {
    this.getBellCount();
    this.getMaintenanceData();
  }

  /**
   * Get text color based on position
   * Position 1: Red - #cb4335
   * Position 2: Orange - #ff9f0c
   * Position 3+: Green - #008000
   */
  getTextColor(position: string | number): string {
    const pos = Number(position);
    if (pos == 1) {
      return '#cb4335'; // Red
    } else if (pos == 2) {
      return '#ff9f0c'; // Orange
    } else {
      return '#008000'; // Green
    }
  }

  /**
   * Get Bell Count (Maintenance Count)
   */
  getBellCount(): void {
    const req = {
      userid: this.userId,
      departmentid: this.departmentId,
      design_id: this.designationId,
      millcode: this.millCode,
      language: this.languageService.getLanguage,
    };

    this.sterilizerService
      .getmaintenancependingcount(req)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (response: any) => {
          if (response?.httpcode == 200 || response?.httpcode == '200') {
            this.maintenanceCount = response.maintenancecount || 0;
            this.maintenanceCountLength =
              this.maintenanceCount.toString().length;
            this.totalCount = this.maintenanceCount;
          } else {
            this.resetCounts();
          }
        },
        error: () => {
          this.resetCounts();
        },
      });
  }

  /**
   * Reset counts to zero
   */
  private resetCounts(): void {
    this.maintenanceCount = 0;
    this.maintenanceCountLength = 1;
    this.totalCount = 0;
  }

  /**
   * Handle month selected from month picker
   */
  onMonthSelected(event: { month: string }): void {
    console.log('Month selected:', event);
    // Month is in YYYY-MM format from the month picker
    this.reportDateForAPI = event.month;
    // Store in MM-YYYY format for display
    this.reportDateDisplay = this.formatMonthFromString(event.month);
    // Reset external date to avoid overriding user selection
    this.reportDateExternal = '';

    console.log('Month selected - API format:', this.reportDateForAPI);
    console.log('Month selected - Display format:', this.reportDateDisplay);

    // Call API with selected month
    this.getMaintenanceData();
  }

  /**
   * Get Maintenance Data
   */
  getMaintenanceData(): void {
    this.pleaseWaitFlag = true;

    // Use the API format (YYYY-MM) for the request
    const fromDate = this.reportDateForAPI || '';

    const req = {
      userid: this.userId,
      millcode: this.millCode,
      departmentid: this.departmentId,
      designationid: this.designationId,
      fromdate: fromDate,
      language: this.languageService.getLanguage,
    };

    console.log('getMaintenanceData - fromdate:', fromDate);

    this.managementService
      .getMaintenanceData(req)
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        finalize(() => {
          this.pleaseWaitFlag = false;
        }),
      )
      .subscribe({
        next: (response: any) => {
          console.log('Maintenance Data Response:', response);

          // Prefill month date from API response only if no date was sent
          if (!fromDate) {
            if (response?.fromdate) {
              // Store in YYYY-MM format for API
              this.reportDateForAPI = response.fromdate;
              // Store in MM-YYYY format for display
              this.reportDateDisplay = this.formatMonthFromString(
                response.fromdate,
              );
              this.reportDateExternal = response.fromdate;
            }
          }

          if (response?.httpcode == 200 || response?.httpcode == '200') {
            // Set data from response
            this.correctivemaintenanceArr = response.data?.cm || [];
            this.routinepreventivemaintenanceArr = response.data?.ropm || [];
            this.replacementpreventivemaintenanceArr =
              response.data?.repm || [];
            this.predictivemaintenanceArr = response.data?.predictive || [];
          } else {
            // Set default empty data with dashes
            this.setDefaultData();
          }
        },
        error: () => {
          this.setDefaultData();
        },
      });
  }

  /**
   * Set default data with dashes when no data is available
   */
  private setDefaultData(): void {
    this.predictivemaintenanceArr = [
      { title: 'Generated', position: 1, value: '-' },
      { title: 'Created', position: 2, value: '-' },
      { title: 'In Progress', position: 3, value: '-' },
      { title: 'Completed', position: 4, value: '-' },
      { title: 'Rejected', position: 5, value: '-' },
    ];
    this.correctivemaintenanceArr = [
      { title: 'Created', position: 1, value: '-' },
      { title: 'In Progress', position: 2, value: '-' },
      { title: 'Completed', position: 3, value: '-' },
    ];
    this.routinepreventivemaintenanceArr = [
      { title: 'Created', position: 1, value: '-' },
      { title: 'In Progress', position: 2, value: '-' },
      { title: 'Completed', position: 3, value: '-' },
    ];
    this.replacementpreventivemaintenanceArr = [
      { title: 'Created', position: 1, value: '-' },
      { title: 'In Progress', position: 2, value: '-' },
      { title: 'Completed', position: 3, value: '-' },
    ];
  }

  /**
   * Format month from YYYY-MM to MM-YYYY
   */
  private formatMonthFromString(dateStr: string): string {
    if (!dateStr) return '';
    const parts = dateStr.split('-');
    if (parts.length !== 2) return dateStr;
    return `${parts[1]}-${parts[0]}`;
  }

  /**
   * Convert newlines to <br> tags
   */
  private nl2br(text: string): string {
    if (!text) return '';
    return text.replace(new RegExp('\r?\n', 'g'), '<br />');
  }
}
