import { Component, OnInit } from '@angular/core';
import { ViewChild } from '@angular/core';
import { UserContext } from 'src/app/shared/services/user-context-service/user-context';
import { OilLossesComponent } from 'src/app/shared/components/oil-losses/oil-losses.component';

@Component({
  selector: 'app-management-oil-losses',
  templateUrl: './management-oil-losses.page.html',
  styleUrls: ['./management-oil-losses.page.scss'],
  standalone: false,
})
export class ManagementOilLossesPage implements OnInit {
  @ViewChild(OilLossesComponent)
  OilLossesComponent!: OilLossesComponent;

  appTitle = this.nl2br(this.UserContext.millName);
  headerActions = '';
  showLogo = 1;
  showBackButton = 0;
  showNewLoad = false;
  constructor(private UserContext: UserContext) {}

  ngOnInit() {}

  ionViewWillEnter() {
    this.OilLossesComponent.initializeApiCall();
  }

  onDataLoaded(hasData: boolean) {
    console.log('Oil losses data loaded:', hasData);
  }

  nl2br(text: string) {
    return text.replace(new RegExp('\r?\n', 'g'), '<br />');
  }
}
