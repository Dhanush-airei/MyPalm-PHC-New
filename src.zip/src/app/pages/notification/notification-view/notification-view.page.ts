import { Component, OnInit, inject, DestroyRef } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { Location } from '@angular/common';
import { AlertController, ModalController } from '@ionic/angular';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { UserContext } from 'src/app/shared/services/user-context-service/user-context';
import { LanguageService } from 'src/app/shared/services/language-service/language-service';
import { NotificationService } from 'src/app/shared/services/notification-service/notification-service';
import { ToastService } from 'src/app/shared/services/toast-service/toast-service';
import { AlertAcknowledgePage } from 'src/app/pages/production/sterilizer/alert-acknowledge/alert-acknowledge.page';

@Component({
  selector: 'app-notification-view',
  templateUrl: './notification-view.page.html',
  styleUrls: ['./notification-view.page.scss'],
  standalone: false,
})
export class NotificationViewPage implements OnInit {
  private destroyRef = inject(DestroyRef);

  // Header Configuration
  appTitle: string = this.translate.instant('NOTIFICATION.title');
  headerActions: string = '';
  showLogo: number = 0;
  notificationBackButton: number = 1;

  // User Data
  userContext = inject(UserContext);
  designationid: number = this.userContext.designId;
  departmentid: number = this.userContext.departmentId;
  oillossnotificationflag: number = this.userContext.oilloss_notification_flag;

  // Notification Arrays
  todaysnotificationArr: any[] = [];
  oldernotificationArr: any[] = [];

  // Counts
  todaysnotificationcount: number = 0;
  oldernotificationcount: number = 0;

  // Flags
  todaysnotificationflag: boolean = false;
  oldernotificationflag: boolean = false;
  todaysnotificationclick: number = 0;
  oldernotificationclick: number = 0;
  filterstatus: string = '';
  enableflag: boolean = false;
  isDisable: boolean = false;
  isModalActive: boolean = false;

  // Date
  currentdate: string = '';
  alertnotificationArr: any[] = [];

  constructor(
    private languageService: LanguageService,
    private translate: TranslateService,
    private notificationService: NotificationService,
    private alertController: AlertController,
    public modalController: ModalController,
    private router: Router,
    private location: Location,
    private toastService: ToastService,
  ) {
    this.setCurrentDate();

    // Check if user has access to this page
    const allowedDesignations = [1, 3, 4, 5, 6, 7, 8, 9, 11, 15];
    if (allowedDesignations.includes(this.designationid)) {
      if (this.designationid == 3) {
        this.getAlert();
      } else {
        this.getNotification();
      }
    }
  }

  ngOnInit() {}

  ionViewDidEnter() {
    const allowedDesignations = [1, 3, 4, 5, 6, 7, 8, 9, 11, 15];
    if (allowedDesignations.includes(this.designationid)) {
      if (this.designationid == 3) {
        this.getAlert();
      } else {
        this.getNotification();
      }
    }
  }

  /**
   * Set current date in DD-MM-YYYY format
   */
  private setCurrentDate(): void {
    const now = new Date();
    const day = String(now.getDate()).padStart(2, '0');
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const year = now.getFullYear();
    this.currentdate = `${day}-${month}-${year}`;
  }

  /**
   * Get border color based on notification type
   */
  getBorderColor(value: string): string {
    let color = '#ffffff';

    if (value == '1')
      color = '#FF9800'; // Sterilizer
    else if (value == '2')
      color = '#03A9F4'; // Press
    else if (value == '3')
      color = '#F44336'; // Oil loss
    else if (value == '4')
      color = '#4CAF50'; // Grading
    else if (value == '6') color = '#B82E8A'; // Sensor Data

    return color;
  }

  /**
   * Get background color based on notification type
   */
  getBackgroundColor(value: string): string {
    let color = '#ffffff';

    if (value == '1')
      color = '#FFF3E0'; // Sterilizer
    else if (value == '2')
      color = '#E1F5FE'; // Press
    else if (value == '3')
      color = '#FFEBEE'; // Oil loss
    else if (value == '4')
      color = '#E8F5E9'; // Grading
    else if (value == '6') color = '#FAEBF5'; // Sensor Data

    return color;
  }

  /**
   * Get text color (always white for header)
   */
  getTextColor(value: string): string {
    return '#ffffff';
  }

  /**
   * Toggle today's notification visibility
   */
  gettodaysnotification(): void {
    this.todaysnotificationclick = this.todaysnotificationclick === 0 ? 1 : 0;
    this.oldernotificationclick = 0;

    this.todaysnotificationflag = this.todaysnotificationclick === 1;
    this.oldernotificationflag = false;
  }

  /**
   * Toggle older notification visibility
   */
  getoldernotification(): void {
    this.todaysnotificationclick = 0;
    this.oldernotificationclick = this.oldernotificationclick === 0 ? 1 : 0;

    this.todaysnotificationflag = false;
    this.oldernotificationflag = this.oldernotificationclick === 1;
  }

  /**
   * Get Alert Notifications (Designation 3)
   */
  getAlert(): void {
    const req = {
      userid: this.userContext.userId,
      departmentid: this.userContext.departmentId,
      millcode: this.userContext.millCode,
      filter: '4',
      language: this.languageService.getLanguage,
    };

    console.log('Alert Request:', req);

    this.notificationService
      .getalertnotification(req)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (result: any) => {
          console.log('Alert Response:', result);
          if (result.httpcode == 200) {
            this.todaysnotificationcount = result.todaycount || 0;
            this.oldernotificationcount = result.oldercount || 0;

            // Process today's notifications
            if (result.data.today && result.data.today.length > 0) {
              this.todaysnotificationArr = result.data.today.map(
                (item: any) => ({
                  ...item,
                  notification_text: this.nl2br(item.notification_text),
                }),
              );
            } else {
              this.todaysnotificationArr = [];
            }

            // Process older notifications
            if (result.data.older && result.data.older.length > 0) {
              this.oldernotificationArr = result.data.older.map(
                (item: any) => ({
                  ...item,
                  notification_text: this.nl2br(item.notification_text),
                }),
              );
            } else {
              this.oldernotificationArr = [];
            }

            this.enableflag = false;
          } else {
            this.todaysnotificationcount = 0;
            this.oldernotificationcount = 0;
            this.todaysnotificationArr = [];
            this.oldernotificationArr = [];
            this.enableflag = true;
          }
        },
        error: (err) => {
          console.error('Failed to get alerts:', err);
          this.todaysnotificationcount = 0;
          this.oldernotificationcount = 0;
          this.todaysnotificationArr = [];
          this.oldernotificationArr = [];
          this.enableflag = true;
        },
      });
  }

  /**
   * Get General Notifications
   */
  getNotification(): void {
    // Set filter based on designation
    if (this.designationid == 1 || this.designationid == 3) {
      this.filterstatus = '4';
    } else if (
      this.designationid == 7 ||
      this.designationid == 8 ||
      this.designationid == 9 ||
      this.designationid == 15
    ) {
      this.filterstatus = '3';
    } else if (
      this.designationid == 4 ||
      this.designationid == 5 ||
      this.designationid == 6 ||
      this.designationid == 11
    ) {
      this.filterstatus = '2';
    }

    const req = {
      userid: this.userContext.userId,
      departmentid: this.userContext.departmentId,
      designationid: this.userContext.designId,
      millcode: this.userContext.millCode,
      filter: this.filterstatus,
      language: this.languageService.getLanguage,
    };

    console.log('Notification Request:', req);

    this.notificationService
      .getsegregatenotification(req)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (result: any) => {
          console.log('Notification Response:', result);
          if (result.httpcode == 200) {
            this.todaysnotificationcount = result.todaycount || 0;
            this.oldernotificationcount = result.oldercount || 0;
            this.todaysnotificationArr = result.data.today || [];
            this.oldernotificationArr = result.data.older || [];
            this.enableflag = false;
          } else {
            this.todaysnotificationcount = 0;
            this.oldernotificationcount = 0;
            this.todaysnotificationArr = [];
            this.oldernotificationArr = [];
            this.enableflag = true;
          }
        },
        error: (err) => {
          console.error('Failed to get notifications:', err);
          this.todaysnotificationcount = 0;
          this.oldernotificationcount = 0;
          this.todaysnotificationArr = [];
          this.oldernotificationArr = [];
          this.enableflag = true;
        },
      });
  }

  /**
   * Handle rectify button click
   */
  btn_rectify(value: any): void {
    this.callModalController(value);
  }

  /**
   * Handle not rectify button click
   */
  async btn_notrectify(value: any): Promise<void> {
    const alertmessage = this.translate.instant('ALERTACKNOWLEDGE.reasontitle');

    const alert = await this.alertController.create({
      mode: 'md',
      header: '',
      message: alertmessage,
      cssClass: 'customalertmessagetwobuttons',
      backdropDismiss: false,
      inputs: [
        {
          name: 'reason',
          type: 'textarea',
          cssClass: 'alertinput',
          placeholder: this.translate.instant(
            'ALERTACKNOWLEDGE.reasonplaceholder',
          ),
        },
      ],
      buttons: [
        {
          text: '',
          role: 'cancel',
          handler: () => {
            // Cancel
          },
        },
        {
          text: '',
          handler: (data: any) => {
            if (data.reason && data.reason.trim() !== '') {
              this.save(data.reason, '2', value.baseid, value.id, value.type);
              return true;
            } else {
              this.toastService.error(
                this.translate.instant('ALERTACKNOWLEDGE.reasonmandatory'),
              );
              return false;
            }
          },
        },
      ],
    });

    await alert.present();
  }

  /**
   * Save alert notification update
   */
  save(
    getreason: string,
    getrectifystatus: string,
    getbaseid: any,
    getid: any,
    gettype: any,
  ): void {
    const req = {
      userid: this.userContext.userId,
      departmentid: this.userContext.departmentId,
      designationid: this.userContext.designId,
      millcode: this.userContext.millCode,
      baseid: getbaseid,
      id: getid,
      type: gettype,
      rectify_status: getrectifystatus,
      remarks: getreason,
      language: this.languageService.getLanguage,
    };

    this.notificationService
      .updatealertnotification(req)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (result: any) => {
          this.isDisable = false;

          if (result.httpcode == 200) {
            if (getrectifystatus == '2') {
              this.toastService.success(
                this.translate.instant(
                  'ALERTACKNOWLEDGE.unabletorectifysuccess',
                ),
              );
            }
            this.getAlert();
          } else {
            if (getrectifystatus == '2') {
              this.toastService.error(
                this.translate.instant(
                  'ALERTACKNOWLEDGE.unabletorectifyfailed',
                ),
              );
            }
          }
        },
        error: (err) => {
          console.error('Failed to update alert:', err);
          this.isDisable = false;
          if (getrectifystatus == '2') {
            this.toastService.error(
              this.translate.instant('ALERTACKNOWLEDGE.unabletorectifyfailed'),
            );
          }
        },
      });
  }

  /**
   * Update notification (mark as read)
   */
  updateNotification(value: any): void {
    // Check if it's Weighbridge notification
    if (value.redirect == 'WEIGHBRIDGE WEIGHT UPDATE') {
      this.updateWeight(value);
      return;
    }

    const req = {
      user_id: this.userContext.userId,
      millcode: this.userContext.millCode,
      id: value.id,
      filter: this.filterstatus,
      language: this.languageService.getLanguage,
    };

    this.notificationService
      .deletedasboardnotification(req)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (result: any) => {
          if (result.httpcode == 200) {
            if (value.rectify_status == 0) {
              this.redirectController(value);
            }
          } else {
            this.toastService.error(
              this.translate.instant('SEGREGATENOTIFICATION.message'),
            );
          }
        },
        error: (err) => {
          console.error('Failed to update notification:', err);
          this.toastService.error(
            this.translate.instant('SEGREGATENOTIFICATION.message'),
          );
        },
      });
  }

  /**
   * Redirect based on notification type
   */
  redirectController(value: any): void {
    this.getNotification();

    if (value.redirect == 'CORRECTIVE MAINTENANCE NOTIFICATION') {
      if (this.designationid == 5 || this.designationid == 11) {
        localStorage.setItem('notificationdata', value.redirect);
        this.router.navigate(['/tabs']);
      } else {
        localStorage.setItem('notificationdata', value.redirect);
        this.router.navigate(['/tabs/tabcorrectivemaintenance']);
      }
    } else if (
      value.redirect == 'ROUTINE PREVENTIVE MAINTENANCE NOTIFICATION'
    ) {
      if (this.designationid == 5 || this.designationid == 11) {
        localStorage.setItem('notificationdata', value.redirect);
        this.router.navigate(['/tabs']);
      } else {
        localStorage.setItem('notificationdata', value.redirect);
        this.router.navigate(['/tabs/tabpreventivemaintenance']);
      }
    } else if (
      value.redirect == 'REPLACEMENT PREVENTIVE MAINTENANCE NOTIFICATION'
    ) {
      if (this.designationid == 5 || this.designationid == 11) {
        localStorage.setItem('notificationdata', value.redirect);
        this.router.navigate(['/tabs']);
      } else {
        localStorage.setItem('notificationdata', value.redirect);
        this.router.navigate(['/tabs/tabpreventivemaintenance']);
      }
    } else if (
      value.redirect == 'CORRECTIVE MAINTENANCE NOTIFICATION ACKNOWLEDGEMENT'
    ) {
      localStorage.setItem('notificationdata', value.redirect);
      this.router.navigate(['/tabs/tabcorrectivemaintenance']);
    } else if (
      value.redirect ==
      'ROUTINE PREVENTIVE MAINTENANCE NOTIFICATION ACKNOWLEDGEMENT'
    ) {
      localStorage.setItem('notificationdata', value.redirect);
      this.router.navigate(['/tabs/tabpreventivemaintenance']);
    } else if (
      value.redirect ==
      'REPLACEMENT PREVENTIVE MAINTENANCE NOTIFICATION ACKNOWLEDGEMENT'
    ) {
      localStorage.setItem('notificationdata', value.redirect);
      this.router.navigate(['/tabs/tabpreventivemaintenance']);
    } else if (value.redirect == 'HOURLY PRESS') {
      this.router.navigate(['/production-hourlypressingstation']);
    } else if (value.redirect == 'HOURLY STERILIZER') {
      this.router.navigate([
        '/production-hourlysterilizerstation',
        { item: '' },
      ]);
    } else if (value.redirect == 'HOURLY OIL LOSS') {
      this.router.navigate(['/tabs']);
    } else if (value.redirect == 'HIGH OIL LOSS') {
      this.router.navigate(['/dashboard-oilloss-predictionanalysis']);
    } else if (value.redirect == 'CPO PRODUCTION') {
      this.router.navigate(['/report-cpoproduction-and-oer']);
    }
  }

  /**
   * Open Alert Acknowledge Modal
   */
  async callModalController(value: any): Promise<void> {
    this.isModalActive = true;

    const modal = await this.modalController.create({
      component: AlertAcknowledgePage,
      componentProps: {
        item: JSON.stringify(value),
      },
      showBackdrop: true,
      backdropDismiss: false,
      cssClass: ['alertattend-modal'],
    });

    modal.onDidDismiss().then((data) => {
      this.isModalActive = false;
      this.getAlert();
    });

    await modal.present();
  }

  /**
   * Update Weighbridge Weight
   */
  async updateWeight(value: any): Promise<void> {
    // Uncomment when WeighbridgeUpdateReportScreenPage is available
    // const weighbridgemodal = await this.modalController.create({
    //   component: WeighbridgeUpdateReportScreenPage,
    //   componentProps: {
    //     item: JSON.stringify(value),
    //     module: 'NOTIFICATION SCREEN',
    //   },
    //   showBackdrop: true,
    //   backdropDismiss: false,
    //   cssClass: ['weighbridgepopup-modal'],
    // });
    // weighbridgemodal.onDidDismiss().then((modaldata) => {
    //   const getdata = modaldata?.data?.item;
    //   if (getdata != '') {
    //     this.getNotification();
    //   }
    // });
    // await weighbridgemodal.present();
  }

  /**
   * Convert newline to <br>
   */
  nl2br(text: string): string {
    if (!text) return '';
    return text.replace(new RegExp('\r?\n', 'g'), '<br />');
  }

  /**
   * Go back to previous page
   */
  back(): void {
    this.location.back();
  }
}
