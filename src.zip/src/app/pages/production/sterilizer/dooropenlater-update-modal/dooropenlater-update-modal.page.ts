/* dooropenlater-update-modal.page.ts */

import { Component, OnInit, DestroyRef, inject } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  Validators,
  FormGroup,
} from '@angular/forms';
import { ModalController, NavParams } from '@ionic/angular';
import { finalize } from 'rxjs';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { TranslateService } from '@ngx-translate/core';
import { UserContext } from 'src/app/shared/services/user-context-service/user-context';
import { LanguageService } from 'src/app/shared/services/language-service/language-service';
import { SterilizerService } from 'src/app/shared/services/production-services/sterilizer-service/sterilizer-service';
import { ToastService } from 'src/app/shared/services/toast-service/toast-service';

@Component({
  selector: 'app-dooropenlater-update-modal',
  templateUrl: './dooropenlater-update-modal.page.html',
  styleUrls: ['./dooropenlater-update-modal.page.scss'],
  standalone: false,
})
export class DooropenlaterUpdateModalPage implements OnInit {
  private destroyRef = inject(DestroyRef);

  // Form
  doorOpenLaterForm!: FormGroup;

  // User Data
  getLanguage: string = '';
  userId: number = 0;
  millCode: string = '';
  departmentId: number = 0;

  // Variables
  params: any;
  isDisabled: boolean = false;

  // Date Time Picker
  isDateTimePickerOpen: boolean = false;
  selectedDateTime: string = '';
  tempDateTime: string = '';
  minDateTime: string = '';

  constructor(
    private modalController: ModalController,
    private navParams: NavParams,
    private fb: FormBuilder,
    private userContext: UserContext,
    private languageService: LanguageService,
    private sterilizerService: SterilizerService,
    private toastService: ToastService,
    private translate: TranslateService,
  ) {
    this.initializeUserData();
    this.initializeParams();
    this.createForm();
  }

  ngOnInit() {}

  /**
   * Initialize user data from UserContext
   */
  private initializeUserData(): void {
    this.userId = this.userContext.userId;
    this.millCode = this.userContext.millCode;
    this.departmentId = this.userContext.departmentId;
    this.getLanguage = this.languageService.getLanguage;
  }

  /**
   * Initialize params from NavParams
   */
  private initializeParams(): void {
    const viewform = this.navParams.get('item');
    this.params = JSON.parse(viewform);

    // Set minimum date time to door shut time
    if (this.params.door_shut_time) {
      const parsedDate = this.parseDate(this.params.door_shut_time);
      this.minDateTime = this.formatDateTimeISO(parsedDate);
    }
  }

  /**
   * Create form
   */
  private createForm(): void {
    this.doorOpenLaterForm = this.fb.group({
      txt_dooropentime: new FormControl('', Validators.required),
    });
  }

  /**
   * Parse date string in DD-MM-YYYY HH:mm format
   */
  private parseDate(dateStr: string): Date {
    if (!dateStr) return new Date();

    let day, month, year, hour, minute;

    if (dateStr.includes('-')) {
      const parts = dateStr.split(' ');
      const dateParts = parts[0].split('-');

      if (dateParts[0].length === 4) {
        year = parseInt(dateParts[0]);
        month = parseInt(dateParts[1]) - 1;
        day = parseInt(dateParts[2]);
      } else {
        day = parseInt(dateParts[0]);
        month = parseInt(dateParts[1]) - 1;
        year = parseInt(dateParts[2]);
      }

      if (parts.length > 1) {
        const timeParts = parts[1].split(':');
        hour = parseInt(timeParts[0]);
        minute = parseInt(timeParts[1]);
      } else {
        hour = 0;
        minute = 0;
      }
    } else {
      return new Date(dateStr);
    }

    return new Date(year, month, day, hour || 0, minute || 0);
  }

  /**
   * Format date to YYYY-MM-DDTHH:mm format for datetime picker
   */
  private formatDateTimeISO(date: Date): string {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');

    return `${year}-${month}-${day}T${hours}:${minutes}`;
  }

  /**
   * Format date to YYYY-MM-DD HH:mm:00 for API
   */
  private formatDateTime(date: Date): string {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');

    return `${year}-${month}-${day} ${hours}:${minutes}:00`;
  }

  /**
   * Open DateTime Picker
   */
  openDateTimePicker(): void {
    this.tempDateTime =
      this.selectedDateTime || this.formatDateTimeISO(new Date());
    this.isDateTimePickerOpen = true;
  }

  /**
   * DateTime changed
   */
  onDateTimeChange(event: CustomEvent): void {
    const value = event.detail.value;
    if (!value) return;
    this.tempDateTime = value;
  }

  /**
   * DateTime modal dismissed
   */
  onDateTimeDismiss(): void {
    if (this.tempDateTime) {
      this.selectedDateTime = this.tempDateTime;
      this.doorOpenLaterForm.patchValue({
        txt_dooropentime: this.selectedDateTime,
      });
    }
    this.isDateTimePickerOpen = false;
  }

  /**
   * Save door open time
   */
  save(): void {
    const doorOpenTimeValue = this.doorOpenLaterForm.value.txt_dooropentime;

    if (!doorOpenTimeValue) {
      this.toastService.warning(
        this.translate.instant(
          'HOURLYSTERILIZATIONSTATIONSAVE.dooropentimemandatory',
        ),
      );
      return;
    }

    const startDate = this.parseDate(this.params.door_shut_time);
    const endDate = this.parseDate(doorOpenTimeValue);

    if (endDate <= startDate) {
      this.toastService.error(
        this.translate.instant(
          'HOURLYSTERILIZATIONSTATIONSAVE.doorshutandopentimevalidation',
        ),
      );
      return;
    }

    const doorOpenTime = this.formatDateTime(endDate);

    const req = {
      userid: this.userId,
      millcode: this.millCode,
      dept_id: this.departmentId,
      id: this.params.id,
      door_open_time: doorOpenTime,
    };

    console.log('Save Door Open Time Request:', req);

    this.isDisabled = true;

    this.sterilizerService
      .saveDoorOpenTimeLater(req)
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        finalize(() => {
          this.isDisabled = false;
        }),
      )
      .subscribe({
        next: (response: any) => {
          if (response?.httpcode === 200) {
            this.doorOpenLaterForm.reset();
            this.selectedDateTime = '';
            this.toastService.success(
              this.translate.instant('HOURLYSTERILIZATIONSTATIONSAVE.success'),
            );
            this.modalController.dismiss({
              dismissed: true,
              item: 'SAVED',
            });
          } else {
            this.toastService.error(
              this.translate.instant('HOURLYSTERILIZATIONSTATIONSAVE.failed'),
            );
          }
        },
        error: (err) => {
          console.error('Failed to save door open time:', err);
          this.toastService.error(
            this.translate.instant('HOURLYSTERILIZATIONSTATIONSAVE.failed'),
          );
        },
      });
  }

  /**
   * Close modal
   */
  btnClose(): void {
    this.modalController.dismiss({
      dismissed: true,
      item: '',
    });
  }
}
