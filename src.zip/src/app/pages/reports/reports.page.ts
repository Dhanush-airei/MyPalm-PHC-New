import { Component, OnInit, inject, DestroyRef } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { UserContext } from 'src/app/shared/services/user-context-service/user-context';
import { Router } from '@angular/router';
import { LanguageService } from 'src/app/shared/services/language-service/language-service';
import { SterilizerService } from 'src/app/shared/services/production-services/sterilizer-service/sterilizer-service';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

interface ReportItem {
  title: string;
  subtitle: string;
  img: string;
  path: string;
}

interface ReportGroup {
  report_name: string;
  reportArr: ReportItem[];
}

@Component({
  selector: 'app-reports',
  templateUrl: './reports.page.html',
  styleUrls: ['./reports.page.scss'],
  standalone: false,
})
export class ReportsPage implements OnInit {
  private destroyRef = inject(DestroyRef);

  fmanagerArrReport: ReportGroup[] = [
    {
      report_name: 'Production Reports',
      reportArr: [
        {
          title: this.translate.instant('PRODUCTIONHOME.sterilizationtitle'),
          subtitle: this.translate.instant('PRODUCTIONHOME.subtitlestation'),
          img: '../../assets/img/sterilizer_ report.png',
          path: '/sterilizer-report',
        },
        {
          title: this.translate.instant('PRODUCTIONHOME.pressingtitle'),
          subtitle: this.translate.instant('PRODUCTIONHOME.pressingsubtitle'),
          img: '../../assets/img/press_report.png',
          path: '/press-report',
        },
        {
          title: this.translate.instant('OILLOSSESSREPORT.oillosses'),
          subtitle: this.translate.instant('OILLOSSESSREPORT.summary'),
          img: '../../assets/img/oil_loss.png',
          path: '/oil-losses-summary',
        },
        {
          title: 'Performance',
          subtitle: 'Analysis',
          img: '../../assets/img/performanceanalysis.png',
          path: '/performance-analysis',
        },
      ],
    },
    {
      report_name: 'Maintenance Reports',
      reportArr: [
        {
          title: this.translate.instant('PRODUCTIONHOME.correctivetitle'),
          subtitle: this.translate.instant('PRODUCTIONHOME.correctivesubtitle'),
          img: '../../assets/img/corrective_report.png',
          path: '/corrective-maintenance',
        },
        {
          title: this.translate.instant('PRODUCTIONHOME.preventivetitle'),
          subtitle: this.translate.instant('PRODUCTIONHOME.preventivesubtitle'),
          img: '../../assets/img/preventive_report.png',
          path: '/preventive-maintenance',
        },
        {
          title: 'Predictive',
          subtitle: 'Maintenance',
          img: '../../assets/img/predictivemaintenance.png',
          path: '/predictive-maintenance',
        },
        {
          title: 'Machineries',
          subtitle: 'Running Hours',
          img: '../../assets/img/cpooerreport.png',
          path: '/machineries-running-hours',
        },
        {
          title: 'Part',
          subtitle: 'Running Hours',
          img: '../../assets/img/machinerunninghours.png',
          path: '/part-running-hours',
        },
      ],
    },
    {
      report_name: 'Lab Reports',
      reportArr: [
        {
          title: this.translate.instant('DEPARTMENTS.Laboratory'),
          subtitle: this.nl2br('<br>'),
          img: '../../assets/img/labdailyreport.png',
          path: '/laboratory',
        },
        {
          title: this.translate.instant('OILLOSSESSREPORT.ffa'),
          subtitle: 'Quality',
          img: '../../assets/img/ffa.png',
          path: '/daily-ffa-quality',
        },
        {
          title: 'CPO/PK',
          subtitle: 'Stock',
          img: '../../assets/img/oilreport-removebg-preview.png',
          path: '/cpo-pk-stock',
        },
      ],
    },
    {
      report_name: 'Grading Reports',
      reportArr: [
        {
          title: 'Weighbridge',
          subtitle: this.nl2br('<br>'),
          img: '../../assets/img/weighbridge.png',
          path: '/grading/weighbridge',
        },
        {
          title: 'Supply Chain &',
          subtitle: 'Traceability',
          img: '../../assets/img/tracability-icon.png',
          path: '/grading/traceability',
        },
        {
          title: 'FFB Grading',
          subtitle: 'Reports',
          img: '../../assets/img/gradingreport.png',
          path: '/grader-report',
        },
      ],
    },
  ];

  appTitle = this.nl2br(this.userContext.millName);
  headerActions = '';
  showLogo = 1;
  showBackButton = 0;
  showNewLoad = false;

  // Notification Counts
  count: number = 0;
  pendingcount: number = 0;
  pendingcountlength: number = 0;

  isFirstLoad: Boolean = true;

  constructor(
    private translate: TranslateService,
    private userContext: UserContext,
    private router: Router,
    private languageService: LanguageService,
    private sterilizerService: SterilizerService,
  ) {}

  ngOnInit(): void {
    this.initializeReports();
  }

  ionViewDidEnter() {
    if (this.isFirstLoad) {
      // this.isFirstLoad = false;
      this.getProductionPendingCount();
    }
  }

  /**
   * Initialize reports - can be used for additional setup
   */
  private initializeReports(): void {
    this.getProductionPendingCount();
  }

  /**
   * Navigate to report detail page
   */
  navigateToReport(report: ReportItem): void {
    if (report.path) {
      this.router.navigate([report.path]);
    }
  }

  /**
   * Get production pending count
   */
  getProductionPendingCount(): void {
    const req = {
      userid: this.userContext.userId,
      departmentid: this.userContext.departmentId,
      design_id: this.userContext.designId,
      millcode: this.userContext.millCode,
      language: this.languageService.getLanguage,
    };

    console.log(req);

    this.sterilizerService
      .getmaintenancependingcount(req)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (result: any) => {
          if (result.httpcode == 200) {
            this.pendingcount = result.count;
            this.pendingcountlength = this.pendingcount.toString().length;
          } else {
            this.pendingcount = 0;
            this.pendingcountlength = this.pendingcount.toString().length;
          }
        },
        error: (err) => {
          console.error('Failed to get pending count:', err);
          this.pendingcount = 0;
          this.pendingcountlength = this.pendingcount.toString().length;
        },
      });
  }

  /**
   * Convert newlines to <br> tags
   */
  private nl2br(text: string): string {
    if (!text) return '';
    return text.replace(new RegExp('\r?\n', 'g'), '<br />');
  }

  /**
   * Track by function for ngFor optimization
   */
  trackByReportGroup(index: number, item: ReportGroup): string {
    return item.report_name;
  }

  /**
   * Track by function for report items
   */
  trackByReport(index: number, item: ReportItem): string {
    return item.title + item.subtitle;
  }
}
