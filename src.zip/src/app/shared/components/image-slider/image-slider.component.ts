/* image-slider.component.ts */

import { Component, OnInit } from '@angular/core';
import { ModalController, NavParams } from '@ionic/angular';
import { TranslateService } from '@ngx-translate/core';

export interface SliderImage {
  image: string;
  title: string;
}

@Component({
  selector: 'app-image-slider',
  templateUrl: './image-slider.component.html',
  styleUrls: ['./image-slider.component.scss'],
  standalone: false,
})
export class ImageSliderComponent implements OnInit {
  /**
   * From Screen
   */
  from = '';

  /**
   * Images
   */
  imagesArr: SliderImage[] = [];

  /**
   * Swiper Config
   */
  swiperOptions = {
    slidesPerView: 1,
    spaceBetween: 10,
    centeredSlides: true,
    navigation: true,
    pagination: {
      clickable: true,
    },
    zoom: true,
  };
  showBackButton = 0;
  showLogo = 0;
  appTitle = this.translate.instant('IMAGESLIDER.viewimage');
  headerActions = '5';

  constructor(
    private modalController: ModalController,
    private navParams: NavParams,
    private translate: TranslateService,
  ) {}

  ngOnInit(): void {
    this.from = this.navParams.get('from') ?? '';
    this.loadImages();
  }

  /**
   * Load Images
   */
  loadImages(): void {
    if (this.from === 'Grading' || this.from === 'GradingReport') {
      this.loadGradingImages();
    } else if (this.from === 'BPV' || this.from === 'Peak') {
      this.loadSterilizerImages();
    } else if (this.from === 'Alert') {
      this.loadAlertImages();
    }
    console.log('loadImages - from:', this.from);
  }

  /**
   * Load Alert Images
   */
  private loadAlertImages(): void {
    const alertItem = this.navParams.get('alertitem');

    if (!alertItem) {
      console.log('No alertitem found for Alert');
      return;
    }

    const imageArray = this.convertToArray(alertItem);

    console.log('Image array for Alert:', imageArray);

    const titlePrefix = this.translate.instant('IMAGESLIDER.image');

    imageArray.forEach((image: string, index: number) => {
      this.imagesArr.push({
        image: image,
        title: titlePrefix + ' ' + (index + 1),
      });
    });
  }

  /**
   * Load Sterilizer Images (BPV & Peak)
   */
  private loadSterilizerImages(): void {
    const gradingItem = this.navParams.get('gradingitem');

    if (!gradingItem) {
      console.log('No gradingitem found for', this.from);
      return;
    }

    const imageArray = this.convertToArray(gradingItem);

    console.log('Image array for', this.from, ':', imageArray);

    // Set title based on type
    let titlePrefix = '';
    if (this.from === 'BPV') {
      titlePrefix = this.translate.instant(
        'HOURLYSTERILIZATIONSTATIONSAVE.bpvimages',
      );
    } else if (this.from === 'Peak') {
      titlePrefix = this.translate.instant(
        'HOURLYSTERILIZATIONSTATIONSAVE.peakimages',
      );
    }

    imageArray.forEach((image: string, index: number) => {
      this.imagesArr.push({
        image: image,
        title: titlePrefix + ' ' + (index + 1),
      });
    });
  }

  /**
   * Grading Images
   */
  private loadGradingImages(): void {
    const gradingItem = this.navParams.get('gradingitem');

    if (!gradingItem) {
      return;
    }

    const imageArray = this.convertToArray(gradingItem);

    imageArray.forEach((image: string, index: number) => {
      this.imagesArr.push({
        image: image,
        title: this.translate.instant('IMAGESLIDER.image') + ' ' + (index + 1),
      });
    });
  }

  /**
   * Convert Image Data
   */
  private convertToArray(data: string | string[]): string[] {
    if (!data) {
      return [];
    }

    if (Array.isArray(data)) {
      return data;
    }

    return data
      .split('~')
      .map((item) => item.trim())
      .filter((item) => item);
  }

  /**
   * Modal Close
   */
  dismiss(): void {
    this.modalController.dismiss({
      dismissed: true,
    });
  }
}
