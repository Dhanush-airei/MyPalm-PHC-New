/* maintenance.service.ts */
import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { API_ENDPOINTS } from 'src/app/shared/constants/api-endpoints';
import { HttpUtils } from 'src/app/shared/utils/http-utlis';
import { Router } from '@angular/router';
import { NavController } from '@ionic/angular';

@Injectable({
  providedIn: 'root',
})
export class MaintenanceService {
  private http = inject(HttpClient);

  constructor(
    private router: Router,
    private navCtrl: NavController,
  ) {}

  /**
   * Get Incharge Person List
   */
  getInchargePerson(payload: Record<string, unknown>): Observable<any> {
    const endpoint = localStorage.getItem('endpoint');
    const userList = JSON.parse(localStorage.getItem('userlist') || '{}');
    const url = `${userList.report_url}MobileAPI/${API_ENDPOINTS.get_incharge_person_list}`;
    const params = HttpUtils.toFormData(payload);

    return this.http.post<any>(url, params);
  }

  /**
   * Get Notification List Report
   */
  getNotificationListReport(payload: Record<string, unknown>): Observable<any> {
    const endpoint = localStorage.getItem('endpoint');
    const url = `${endpoint}${API_ENDPOINTS.getmaintenancenotificationlistreport}`;
    const params = HttpUtils.toFormData(payload);

    return this.http.post<any>(url, params);
  }

  /**
   * Get Notification View
   */
  getNotificationView(payload: Record<string, unknown>): Observable<any> {
    const endpoint = localStorage.getItem('endpoint');
    const url = `${endpoint}${API_ENDPOINTS.getmaintenancenotificationview}`;

    let httpParams = new HttpParams();
    httpParams = httpParams.set('user_id', String(payload['user_id'] || ''));
    httpParams = httpParams.set('dept_id', String(payload['dept_id'] || ''));
    httpParams = httpParams.set('millcode', String(payload['millcode'] || ''));
    httpParams = httpParams.set('id', String(payload['id'] || ''));
    httpParams = httpParams.set(
      'language',
      String(payload['language'] || 'English'),
    );

    console.log('getNotificationView URL:', url);
    console.log('getNotificationView Params:', httpParams.toString());

    return this.http.get<any>(url, { params: httpParams });
  }

  /**
   * Get Multi Part Defect View List
   * FIX: Ensure pvflag is properly passed in the request
   */
  getMultiPartDefectViewList(
    payload: Record<string, unknown>,
  ): Observable<any> {
    const endpoint = localStorage.getItem('endpoint');
    const url = `${endpoint}${API_ENDPOINTS.getmultipartdefectviewlist}`;

    // FIX: Use HttpParams for consistent GET request
    let httpParams = new HttpParams();
    httpParams = httpParams.set('userid', String(payload['userid'] || ''));
    httpParams = httpParams.set(
      'departmentid',
      String(payload['departmentid'] || ''),
    );
    httpParams = httpParams.set(
      'designationid',
      String(payload['designationid'] || ''),
    );
    httpParams = httpParams.set('millcode', String(payload['millcode'] || ''));
    httpParams = httpParams.set('id', String(payload['id'] || ''));
    httpParams = httpParams.set(
      'partdefectid',
      String(payload['partdefectid'] || ''),
    );
    httpParams = httpParams.set(
      'stationid',
      String(payload['stationid'] || ''),
    );
    httpParams = httpParams.set(
      'equipment',
      String(payload['equipment'] || ''),
    );
    // FIX: Ensure pvflag is passed correctly
    httpParams = httpParams.set('pvflag', String(payload['pvflag'] || '0'));
    httpParams = httpParams.set(
      'language',
      String(payload['language'] || 'English'),
    );

    console.log('getMultiPartDefectViewList URL:', url);
    console.log('getMultiPartDefectViewList Params:', httpParams.toString());
    console.log('getMultiPartDefectViewList pvflag:', payload['pvflag']);

    return this.http.get<any>(url, { params: httpParams });
  }

  /**
   * Get Part Task List Flag
   */
  getPartTaskListFlag(payload: Record<string, unknown>): Observable<any> {
    const endpoint = localStorage.getItem('endpoint');
    const url = `${endpoint}${API_ENDPOINTS.getparttasklistflag}`;
    const params = HttpUtils.toFormData(payload);

    return this.http.post<any>(url, params);
  }

  /**
   * Get Part Task List
   */
  getPartTaskList(payload: Record<string, unknown>): Observable<any> {
    const endpoint = localStorage.getItem('endpoint');
    const url = `${endpoint}${API_ENDPOINTS.getparttasklist}`;
    const params = HttpUtils.toFormData(payload);

    return this.http.post<any>(url, params);
  }

  /**
   * Get Predictive Notification List Report
   */
  getPredictiveNotificationListReport(
    payload: Record<string, unknown>,
  ): Observable<any> {
    const endpoint = localStorage.getItem('endpoint');
    const url = `${endpoint}${API_ENDPOINTS.getpredictivereport}`;
    const params = HttpUtils.toFormData(payload);

    return this.http.post<any>(url, params);
  }

  /**
   * Get Rejected Predictive Notification List Report
   */
  getRejectedPredictiveNotificationListReport(
    payload: Record<string, unknown>,
  ): Observable<any> {
    const endpoint = localStorage.getItem('endpoint');
    const url = `${endpoint}${API_ENDPOINTS.getpredictiverejectreport}`;
    const params = HttpUtils.toFormData(payload);

    return this.http.post<any>(url, params);
  }

  /**
   * Get Station List
   */
  getStationList(payload: Record<string, unknown>): Observable<any> {
    const endpoint = localStorage.getItem('endpoint');
    const url = `${endpoint}${API_ENDPOINTS.stationlist}`;
    const params = HttpUtils.toFormData(payload);

    return this.http.post<any>(url, params);
  }

  /**
   * Get Machineries Running Hours
   */
  getMachineriesRunningHours(
    payload: Record<string, unknown>,
  ): Observable<any> {
    const endpoint = localStorage.getItem('endpoint');
    const url = `${endpoint}${API_ENDPOINTS.getmachineriesrunninghours}`;
    const params = HttpUtils.toFormData(payload);

    return this.http.post<any>(url, params);
  }

  /**
   * Get Machine List
   */
  getMachineList(payload: Record<string, unknown>): Observable<any> {
    const endpoint = localStorage.getItem('endpoint');
    const url = `${endpoint}${API_ENDPOINTS.machinelist}`;
    const params = HttpUtils.toFormData(payload);

    return this.http.post<any>(url, params);
  }

  /**
   * Get Parts Running Hours List
   */
  getPartsRunningHoursList(payload: Record<string, unknown>): Observable<any> {
    const endpoint = localStorage.getItem('endpoint');
    const url = `${endpoint}${API_ENDPOINTS.machine_runninghours_list}`;

    // FIX: Use HttpParams for consistent GET request
    let httpParams = new HttpParams();
    httpParams = httpParams.set('userid', String(payload['userid'] || ''));
    httpParams = httpParams.set(
      'departmentid',
      String(payload['departmentid'] || ''),
    );
    httpParams = httpParams.set(
      'designationid',
      String(payload['designationid'] || ''),
    );
    httpParams = httpParams.set(
      'stationid',
      String(payload['stationid'] || ''),
    );
    httpParams = httpParams.set(
      'locationid',
      String(payload['locationid'] || ''),
    );
    httpParams = httpParams.set('millcode', String(payload['millcode'] || ''));
    httpParams = httpParams.set(
      'language',
      String(payload['language'] || 'English'),
    );

    console.log('getMultiPartDefectViewList URL:', url);
    console.log('getMultiPartDefectViewList Params:', httpParams.toString());
    console.log('getMultiPartDefectViewList pvflag:', payload['pvflag']);

    return this.http.get<any>(url, { params: httpParams });
  }
}
